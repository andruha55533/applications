<?php
require 'config/database.php';
require 'lib/auth.php';
session_start();

if (!current_user()) header('Location: login.php');

$page = max(1, (int)($_GET['page'] ?? 1));
$per = 5;
$offset = ($page - 1) * $per;

// загальна кількість
$total = $pdo->query("SELECT COUNT(*) FROM images")->fetchColumn();
$data = $pdo->prepare("
  SELECT i.*, u.username,
    (SELECT COUNT(*) FROM likes l WHERE l.image_id = i.id) AS likes,
    (SELECT COUNT(*) FROM comments c WHERE c.image_id = i.id) AS comments
  FROM images i
  JOIN users u ON u.id = i.user_id
  ORDER BY i.created_at DESC
  LIMIT ? OFFSET ?");
$data->execute([$per, $offset]);
$images = $data->fetchAll();
?>
<?php include 'templates/header.php'; ?>
<h2>Галерея</h2>
<a href="upload.php">Завантажити нове</a>
<div class="gallery">
  <?php foreach ($images as $img): ?>
    <div class="card">
      <img src="<?=htmlspecialchars($img['file_path'])?>" alt="">
      <p>Автор: <?=htmlspecialchars($img['username'])?> • <?=htmlspecialchars($img['created_at'])?></p>
      <button class="like-btn" data-id="<?=$img['id']?>">
        Like (<?=$img['likes']?>)
      </button>
      <button class="comment-btn" data-id="<?=$img['id']?>">
        Коментарі (<?=$img['comments']?>)
      </button>
    </div>
  <?php endforeach; ?>
</div>
<div class="pagination">
  <?php for ($i=1; $i<=ceil($total/$per); $i++): ?>
    <a href="?page=<?=$i?>" <?= $i==$page?'class="active"':'' ?>><?=$i?></a>
  <?php endfor; ?>
</div>

<script>
document.querySelectorAll('.like-btn').forEach(btn => {
  btn.onclick = async () => {
    const res = await fetch('comment_like.php', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({action:'like', image_id:btn.dataset.id})
    });
    const json = await res.json();
    if (json.ok) btn.textContent = `Like (${json.likes})`;
  };
});
</script>
<?php include 'templates/footer.php'; ?>
