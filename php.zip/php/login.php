<?php
session_start();
require __DIR__.'/config/database.php';
require __DIR__.'/lib/auth.php';

$message = $_SESSION['flash'] ?? '';
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT id, password, confirmed FROM users WHERE username=?");
    $stmt->execute([$user]);
    $row = $stmt->fetch();

    if ($row && password_verify($pass, $row['password'])) {
        if (!$row['confirmed']) {
            $message = 'Потрібно підтвердити email.';
        } else {
            login_user($row['id']);
            header('Location: gallery.php');
            exit;
        }
    } else {
        $message = 'Невірні дані.';
    }
}
?>
<?php include 'templates/header.php'; ?>
<h2>Увійти</h2>
<?php if ($message): ?><p><?=htmlspecialchars($message)?></p><?php endif; ?>
<form method="post">
  <label>Логін або email:<br><input name="username"></label><br>
  <label>Пароль:<br><input type="password" name="password"></label><br>
  <button type="submit">Увійти</button>
</form>
<?php include 'templates/footer.php'; ?>
