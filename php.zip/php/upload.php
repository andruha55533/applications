<?php
session_start();
require 'config/database.php';
require 'lib/auth.php';
if (!current_user()) die('Увійдіть.');

$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if ($_FILES['img']['error']===UPLOAD_ERR_OK) {
    $path = 'images/'.uniqid().'.png';
    move_uploaded_file($_FILES['img']['tmp_name'], $path);
    $stmt = $pdo->prepare("INSERT INTO images(user_id, file_path) VALUES (?,?)");
    $stmt->execute([current_user(), $path]);
    header('Location: gallery.php');
    exit;
  } else $err = 'Помилка завантаження.';
}
?>
<?php include 'templates/header.php'; ?>
<h2>Завантажити / Зробити фото</h2>
<?php if ($err) echo "<p class='error'>$err</p>"; ?>
<form method="post" enctype="multipart/form-data">
  <input type="file" name="img" accept="image/*">
  <button type="submit">Завантажити</button>
</form>
<hr>
<p>Або зробіть фото з камери:</p>
<video id="cam" autoplay></video><br>
<button id="snap" disabled>Зробити фото</button>
<script>
navigator.mediaDevices.getUserMedia({ video: true })
  .then(s => document.getElementById('cam').srcObject = s)
  .catch(console.error);

document.getElementById('cam').onloadedmetadata = () => {
  document.getElementById('snap').disabled = false;
};
document.getElementById('snap').onclick = () => {
  const v = document.getElementById('cam');
  const c = document.createElement('canvas');
  c.width = v.videoWidth; c.height = v.videoHeight;
  c.getContext('2d').drawImage(v, 0, 0);
  const a = document.createElement('a');
  a.href = c.toDataURL('image/png');
  a.download = 'camshot.png';
  a.click();
};
</script>
<?php include 'templates/footer.php'; ?>
