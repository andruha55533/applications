<?php
session_start();
require __DIR__.'/config/database.php';

$token = $_GET['token'] ?? '';
$message = '';

if ($token) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE confirm_token=? AND confirmed=0");
    $stmt->execute([$token]);
    if ($row = $stmt->fetch()) {
        $pdo->prepare("UPDATE users SET confirmed=1, confirm_token=NULL WHERE id=?")
            ->execute([$row['id']]);
        $message = 'Email підтверджено — тепер можна увійти.';
    } else {
        $message = 'Неправильний або вже використаний токен.';
    }
} else {
    $message = 'Немає токену.';
}
?>
<?php include 'templates/header.php'; ?>
<h2>Підтвердження реєстрації</h2>
<p><?=htmlspecialchars($message)?></p>
<a href="login.php">На вхід</a>
<?php include 'templates/footer.php'; ?>
