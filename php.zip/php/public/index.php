<?php
session_start();
require_once '../config/database.php';
require_once '../inc/functions.php';

$page = $_GET['page'] ?? 'home';
switch ($page) {
    case 'login':
        require '../views/auth/login.php';
        break;
    case 'register':
        require '../views/auth/register.php';
        break;
    case 'editor':
        require '../views/editor.php';
        break;
    case 'gallery':
        require '../views/gallery.php';
        break;
    default:
        require '../views/home.php';
        break;
}
