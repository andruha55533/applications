document.addEventListener('DOMContentLoaded', () => {
  const video = document.getElementById('camera');
  const canvas = document.getElementById('preview');
  const captureBtn = document.getElementById('capture');
  const overlaySelect = document.getElementById('overlay');
  const uploadInput = document.getElementById('uploadImage');
  const thumbList = document.getElementById('thumbList');
  let overlayImg = null;
  
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => { video.srcObject = stream; })
    .catch(console.error);

  overlaySelect.addEventListener('change', () => {
    overlayImg = null;
    if (overlaySelect.value) {
      overlayImg = new Image();
      overlayImg.src = '/overlays/' + overlaySelect.value;
    }
    captureBtn.disabled = !overlayImg && !uploadInput.files.length;
  });

  uploadInput.addEventListener('change', () => {
    const file = uploadInput.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => { overlayImg = new Image(); overlayImg.src = reader.result; captureBtn.disabled = false; }
      reader.readAsDataURL(file);
    }
  });

  captureBtn.addEventListener('click', () => {
    const ctx = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);
    if (overlayImg) ctx.drawImage(overlayImg, 0, 0, canvas.width, canvas.height);
    canvas.toBlob(blob => {
      const thumb = URL.createObjectURL(blob);
      const img = document.createElement('img');
      img.src = thumb;
      thumbList.prepend(img);
    });
  });
});
