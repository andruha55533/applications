<?php
session_start();
require 'config/database.php';
require 'lib/auth.php';
if (!current_user()) die(json_encode(['ok'=>false, 'msg'=>'Не автор.

']));

$input = json_decode(file_get_contents('php://input'), true);
$user = current_user();
$image = $input['image_id'] ?? null;

if ($input['action']==='like') {
  // перевірити чи вже є
  $stmt = $pdo->prepare("SELECT id FROM likes WHERE user_id=? AND image_id=?");
  $stmt->execute([$user, $image]);
  if ($stmt->fetch()) {
    $pdo->prepare("DELETE FROM likes WHERE user_id=? AND image_id=?")
        ->execute([$user, $image]);
  } else {
    $pdo->prepare("INSERT INTO likes(user_id, image_id) VALUES (?,?)")
        ->execute([$user, $image]);
  }
  $likes = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE image_id=?");
  $likes->execute([$image]);
  die(json_encode(['ok'=>true, 'likes'=>$likes->fetchColumn()]));
}

die(json_encode(['ok'=>false]));
