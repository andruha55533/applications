<?php
session_start();
require_once 'lib/auth.php';
require_login();
?>
<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="UTF-8">
  <title>Редактор | ФотоРедактор</title>
  <link rel="stylesheet" href="/static/style.css">
</head>
<body>
  <header class="site-header">
    <a href="/" class="logo">ФотоРедактор</a>
    <nav>
      <a href="/gallery.php">Галерея</a>
      <a href="/logout.php">Вийти</a>
    </nav>
  </header>

  <main class="content editor-page">
    <section class="editor-main">
      <video id="camera" autoplay></video>
      <canvas id="preview"></canvas>
      <select id="overlay">
        <option value="">-- Оберіть накладку --</option>
        <option value="frame1.png">Frame 1</option>
        <option value="frame2.png">Frame 2</option>
      </select>
      <button id="capture" disabled>Зробити фото</button>
      <input type="file" id="uploadImage" accept="image/*">
    </section>
    <aside class="editor-preview">
      <h2>Ваші зображення</h2>
      <div id="thumbList" class="thumb-list">
        <!-- Мінатюри тут -->
      </div>
    </aside>
  </main>

  <footer class="site-footer">
    &copy; <?= date('Y') ?> ФотоРедактор.
  </footer>

  <script src="/static/editor.js"></script>
</body>
</html>
