<!DOCTYPE html><html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/css/styles.css">
<title>MyApp</title>
</head><body>
<header><nav>
  <a href="index.php">Головна</a>
  <?php if (is_logged()): ?>
    <a href="gallery.php">Галерея</a>
    <a href="profile.php">Профіль</a>
    <a href="logout.php">Вихід</a>
  <?php endif; ?>
</nav></header>
<main></main>