<?php
session_start();
require __DIR__.'/config/database.php';
require __DIR__.'/lib/security.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2= $_POST['password2'] ?? '';

    if (!$username || !$email) $errors[] = 'Всі поля повинні бути заповнені.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Недійсний email.';
    if (strlen($password) < 6) $errors[] = 'Пароль має бути ≥6 символів.';
    if ($password !== $password2) $errors[] = 'Паролі не співпадають.';

    if (!$errors) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username=? OR email=?");
        $stmt->execute([$username,$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Користувач з таким логіном або email вже існує.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $token = bin2hex(random_bytes(16));
            $stmt = $pdo->prepare("INSERT INTO users(username,email,password,confirm_token) VALUES(?,?,?,?)");
            $stmt->execute([$username,$email,$hash,$token]);
            mail($email, "Підтвердження реєстрації",
                "Перейдіть за цим посиланням:\n" .
                "https://your-site.com/confirm.php?token=$token");
            $_SESSION['flash'] = 'Реєстрація успішна! Перевірте email.';
            header('Location: login.php');
            exit;
        }
    }
}
?>
<?php include 'templates/header.php'; ?>
<h2>Реєстрація</h2>
<?php foreach ($errors as $e): ?><p class="error"><?=htmlspecialchars($e)?></p><?php endforeach; ?>
<form method="post">
  <label>Ім'я:<br><input name="username" value="<?=htmlspecialchars($username ?? '')?>"></label><br>
  <label>Email:<br><input name="email" value="<?=htmlspecialchars($email ?? '')?>"></label><br>
  <label>Пароль:<br><input type="password" name="password"></label><br>
  <label>Повторіть пароль:<br><input type="password" name="password2"></label><br>
  <button type="submit">Зареєструватися</button>
</form>
<?php include 'templates/footer.php'; ?>
