<?php
$DB_DSN = 'mysql:dbname=photostudio;host=127.0.0.1;charset=utf8mb4';
$DB_USER = 'root';
$DB_PASSWORD = 'yourpassword';

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Помилка підключення: " . $e->getMessage());
}