<?php

function current_user() {
  return $_SESSION['user_id'] ?? null;
}

function is_logged() {
  return isset($_SESSION['user_id']);
}

function require_login() {
  if (!is_logged()) {
    header('Location: login.php');
    exit;
  }
}

function login_user($id) {
  session_regenerate_id(true);
  $_SESSION['user_id'] = $id;
}
